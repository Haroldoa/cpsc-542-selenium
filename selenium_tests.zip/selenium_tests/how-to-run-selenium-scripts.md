1. open vs code terminal
2. cd selenium_tests
3. pip install -r requirements.txt
   1. if you don't have python installed please install latest version https://www.python.org/downloads/
   2. restart computer to have python recognized by terminal
4. have latest chrome installed (automatically done if installed)
5. python seleniumLibrary.py
6. python seleniumLogon.py
